Imports System.IO
Imports System
Imports System.Text
Imports System.Net
Imports Microsoft.VisualBasic
Imports System.Runtime.InteropServices
Imports System.Drawing.Drawing2D

' xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
Public Class Form1
    Inherits System.Windows.Forms.Form

    Dim ArrayIndex As Integer
    Public gstMapFolder As String
    Public lblNotify1 As String
    Public btnReset1 As String
    Public btnPath1 As String
    Public txtPath1 As String

    Public Structure recNode
        Public stName As String
        Public y_value As Integer
        Public x_value As Integer
    End Structure

    Public Nodes() As recNode

    Dim TotalNode As Integer = 5

    Private B() As ctlNode

    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        ' Call the base class
        MyBase.OnPaint(e)

        Dim I As Integer = 570
    End Sub

    Private Sub Read_Setting()
        Dim st() As String
        Dim I As Integer = 0
        Dim K As Integer = 0
        Dim J As Integer = 0
        Dim stNode As String = ""
        Dim stTemp As String = ""

        Dim st1 As String = ""
        Dim n As Integer = 0

        gstVersion1 = Me.GetType.Assembly.GetName.Version.ToString
        With System.Configuration.ConfigurationManager.AppSettings

            gnTotalNode = .Get("gnTotalNode")

            gnNodeWidth = .Get("gnNodeWidth")
            gnNodeHeight = .Get("gnNodeHeight")

            Radius = .Get("Radius")

            gstRGB_Value_Orange = .Get("gstRGB_Value_Orange")
            st = Split(gstRGB_Value_Orange, ",") : Orange1.R = st(0) : Orange1.G = st(1) : Orange1.B = st(2)

            gstRGB_Value_Red = .Get("gstRGB_Value_Red")
            st = Split(gstRGB_Value_Red, ",") : Red1.R = st(0) : Red1.G = st(1) : Red1.B = st(2)

            gstRGB_Value_Black = .Get("gstRGB_Value_Black")
            st = Split(gstRGB_Value_Black, ",") : Black1.R = st(0) : Black1.G = st(1) : Black1.B = st(2)

            gstRGB_Value_Green = .Get("gstRGB_Value_Green")
            st = Split(gstRGB_Value_Green, ",") : Green1.R = st(0) : Green1.G = st(1) : Green1.B = st(2)

            gstMapFolder = Application.StartupPath '.Get("gstMapFolder")

            lblNotify1 = .Get("lblNotify1")
            btnReset1 = .Get("btnReset1")
            btnPath1 = .Get("btnPath1")
            txtPath1 = .Get("txtPath1")
        End With

        TotalNode = gnTotalNode

        ReDim Nodes(TotalNode - 1)        ' Note: Index start with zero. 0 to TotalNode -1

        With System.Configuration.ConfigurationManager.AppSettings
            For I = 0 To TotalNode - 1
                stTemp = .Get("gstNode_" & (I + 1).ToString)

                st = Split(stTemp, ",") ' index start from 1 in setting file

                stNode = UCase(st(0))   ' Node Name, A, B, C, D, E

                Nodes(I).stName = stNode        ' Node name change to Upper Case

                Nodes(I).y_value = st(1)
                Nodes(I).x_value = st(2)

            Next

        End With
    End Sub

    Private Sub Form1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Escape Then
            End
        End If
    End Sub

    Private Sub Locate_New_Control()
        Dim position() As String

        position = Split(lblNotify1, ",")
        lblNotify.Left = position(0)
        lblNotify.Top = position(1)

        position = Split(btnReset1, ",")
        btnReset.Left = position(0)
        btnReset.Top = position(1)

        position = Split(btnPath1, ",")
        btnPath.Left = position(0)
        btnPath.Top = position(1)

        position = Split(txtPath1, ",")
        txtPath.Left = position(0)
        txtPath.Top = position(1)

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim I As Integer = 0
        Dim J As Integer = 0
        Dim K As Integer = 0

        KeyPreview = True

        Call Read_Setting()          ' Nodes Array is handled in this Routine

        Call Locate_New_Control()  ' lblNotify, btnReset, btnPath, txtPath

        Dim st As String = ""

        st = gstVersion1.Substring(0, gstVersion1.Length - 4)
        Me.Text = Me.Text & "Version " & gstVersion1

        Call Show_Node()   ' min = 1, max = 100

        Me.BackgroundImage = Image.FromFile(gstMapFolder & "\dijkstra1.png")  ' & "\map1.png")
        Me.BackgroundImageLayout = ImageLayout.Stretch

        btnPath.Enabled = False
    End Sub

    Private Sub Show_Node()
        Dim I As Integer
        Dim J As Integer
        Dim K As Integer = 0
        ' index start from ZERO
        Dim gIndex As Integer = 0

        ReDim B(TotalNode - 1)           ' create instances for controls

        For I = 0 To TotalNode - 1
            B(I) = New ctlNode

            Me.Controls.Add(B(I))

            B(I).Height = gnNodeHeight
            B(I).Width = gnNodeWidth

            B(I).Relocate1()

            B(I).Left = Nodes(I).x_value - 20          ' offset value
            B(I).Top = Nodes(I).y_value - 40           ' offset value

            B(I).text1 = Nodes(I).stName
            B(I).Label1.Text = B(I).text1
            B(I).Label1.Visible = False

            For J = 0 To 3
                With B(I).G(J)

                    .Left = 1
                    .Top = 1
                    .Width = B(I).Width - 2
                    .Height = B(I).Height - 2
                    .lblNode.Left = 0
                    .lblNode.Top = 0
                    .lblNode.Width = .Width
                    .lblNode.Height = .Height
                    .lblNode.BringToFront()
                    .lblNode.Text = B(I).text1

                End With

                AddHandler B(I).G(J).lblNode.DoubleClick, AddressOf DoubleClickHandler2
            Next

            Show_Node_Color("Node", I, "Green")

            B(I).Tag = I

            AddHandler B(I).Click, AddressOf ClickHandler          ' test for green color
            AddHandler B(I).Label1.Click, AddressOf ClickHandler2  ' test for red color

        Next
    End Sub

    Private Sub Show_Node_Color(ByVal flag As String, ByVal n As Integer, ByVal st As String)
        ' n is index of B, the rest need to hide
        Dim I As Integer = 0
        Dim K As Integer = 0

        K = 3

        If flag = "Node" Then

            For I = 0 To K
                B(n).G(I).Visible = False   ' Hide all firstly
            Next
            Select Case st
                Case "Green" : B(n).G(0).Visible = True
                Case "Orange" : B(n).G(1).Visible = True
                Case "Red" : B(n).G(2).Visible = True
                    'Case "Black" : B(n).Label1.Visible = True
                Case "Black" : B(n).G(K).Visible = True
                    ' Label1 is used to show Node (only for NOT YET OPERATION)
            End Select
        End If
    End Sub

    Public Sub ClickHandler(ByVal sender As Object, ByVal e As System.EventArgs)

        'MsgBox("I am  #" & CType(sender, ctlCarpark).Text)
        'ArrayIndex = Array.IndexOf(B, sender)
        'MsgBox(ArrayIndex)
        'just_test_only(ArrayIndex, "OK", 1)  ' to test GREEN COLOR

    End Sub

    Public Sub DoubleClickHandler2(ByVal sender As Object, ByVal e As System.EventArgs)

        'MsgBox("I am  #" & CType(sender, ctlCarpark).Text)
        'ArrayIndex = Array.IndexOf(B, sender)
        Dim st As String = ""
        st = CType(sender, Label).Text
        'MsgBox("Double Click !", MsgBoxStyle.Information, ArrayIndex)
        Dim idx As Integer = Node_Index(st)
        ' Don't have Checked Value because those control are not Checked Boxes

        'MsgBox(st, MsgBoxStyle.Information, idx)

        Call Assign_Node(st, idx)

    End Sub

    Private Sub Assign_Node(ByVal node1 As String, ByVal index1 As Integer)
        Dim I As Integer = 0
        Dim J As Integer = 0
        Dim K As Integer = 0
        Dim dummy1 As Integer = 123

        If order1 >= 2 Then
            MsgBox("Sorry!!! you already selected 2 nodes for this path")
            Exit Sub
        End If
        Select Case order1

            Case 0
                order1 = order1 + 1
                Selected_Node(index1) = order1
                Node_Color_Change(index1, 2)   ' 2 = Red Color

            Case 1
                order1 = order1 + 1
                Selected_Node(index1) = order1
                Node_Color_Change(index1, 2)
            Case Else
        End Select
        If order1 = 2 Then
            change_Orange_The_Rest_Nodes()
            btnPath.Enabled = True
        End If
        dummy1 = 124
    End Sub

    Private Sub change_Orange_The_Rest_Nodes()
        Dim I As Integer = 0
        For I = 0 To 4
            If Selected_Node(I) = 0 Then
                Node_Color_Change(I, 1)    ' 1 = Orange, 0 = Green
            End If
        Next
    End Sub

    Private Sub Node_Color_Change(ByVal idx1 As Integer, ByVal colorIdx As Integer)
        Dim I As Integer = 0
        Dim J As Integer = 0
        For I = 0 To 4
            If I = idx1 Then
                For J = 0 To 2
                    B(I).G(J).Visible = False
                Next
            Else

            End If

        Next
        B(idx1).G(colorIdx).Visible = True
    End Sub

    Dim Node_Label() As String = {"A", "B", "C", "D", "E"}
    Dim Selected_Node() As Integer = {0, 0, 0, 0, 0}
    Dim order1 As Integer = 0

    Dim vertices As Integer = 5
    Dim graph(,) As Integer = {{0, 2, 0, 6, 4}, _
                               {2, 0, 8, 0, 3}, _
                               {0, 8, 0, 5, 0}, _
                               {6, 0, 5, 0, 0}, _
                               {4, 3, 0, 0, 0}}

    Dim labels() As String = {"A", "B", "C", "D", "E"}

    Dim gnDestination As String = "A"
    Dim gnSource As String = "C"

    Dim inf1 As Integer = 9999
    Dim source_index As Integer ' String
    Dim dest_index As Integer

    Dim dist(4) As Integer
    Dim spt_set(4) As Integer
    Dim parent1(4) As Integer

    Private Function Node_Index(ByVal st As String) As Integer
        Node_Index = 0
        Dim temp As String = ""
        st = st.Trim
        Dim dummy1 As Integer = 0
        For i As Integer = 0 To 4
            temp = Node_Label(i).Trim

            If temp = st Then
                'Return i
                Node_Index = i
                Exit For
            End If
        Next
        dummy1 = 1
    End Function

    Public Sub ClickHandler2(ByVal sender As Object, ByVal e As System.EventArgs)
        'MsgBox("I am Label1 # Tag:" & CType(sender, Label).Tag)
        'just_test_only(CType(sender, Label).Tag, "Node", 3)   ' to test RED COLOR
    End Sub

    Public Sub ClickHandler3(ByVal sender As Object, ByVal e As System.EventArgs)
        'MsgBox("I am Label2 # Tag:" & CType(sender, Label).Tag)
        'just_test_only(CType(sender, Label).Tag, "Error", 2)    ' to test ORANGE COLOR
        'global_NodeID = CType(sender, Label).Tag
    End Sub

    ' xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
    Private Sub btnReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReset.Click
        Dim I As Integer = 0
        Dim J As Integer = 0

        For I = 0 To 4
            Selected_Node(I) = 0
        Next

        For I = 0 To 4
            For J = 0 To 2
                B(I).G(J).Visible = False
            Next
            B(I).G(0).Visible = True
        Next
        order1 = 0
        btnPath.Enabled = False
    End Sub

    Private Sub btnPath_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPath.Click
        'MsgBox("The Results are as follows:" & vbCrLf)
        Dim dummy1 As Integer = 123

        txtPath.Text = ""
        For i As Integer = 0 To 4
            'gnSource = "c"
            'gnDestination = "a"
            If Selected_Node(i) = 1 Then
                gnSource = labels(i)
            End If
            If Selected_Node(i) = 2 Then
                gnDestination = labels(i)
            End If
        Next

        Call Preprocessing()

        txtPath.Text = txtPath.Text & "Shortest path:" & vbCrLf

        dest_index = find_index_mapping(gnDestination)

        print_path(dest_index)

        txtPath.Text = txtPath.Text & vbCrLf

        dummy1 = dist(dest_index)

        txtPath.Text = txtPath.Text & "Shortest Distance = " & dummy1
    End Sub

    Private Sub print_path(ByVal j As Integer)

        'If parent1(i) = -1 Then
        'MsgBox("a" & i)97
        'Convert(char, 97+i)))

        'Return
        'End If 
        If parent1(j) = -1 Then
            'Console.Write(Char.ConvertFromUtf32(Asc("a"c) + i) & " -> ")
            txtPath.Text = txtPath.Text & Char.ConvertFromUtf32(Asc("a"c) + j) & " -> "
            Return
        End If
        print_path(parent1(j))

        If dest_index = j Then
            txtPath.Text = txtPath.Text & Char.ConvertFromUtf32(Asc("a"c) + j)
        Else
            txtPath.Text = txtPath.Text & Char.ConvertFromUtf32(Asc("a"c) + j) & " -> "
        End If
    End Sub

    Private Sub Preprocessing()
        'vertices = InputBox("How many vertices?")
        'MsgBox(vertices)
        Dim dummy1 As Integer = 200
        Dim count1 As Integer
        Dim u As Integer
        Dim v As Integer

        source_index = find_index_mapping(gnSource)

        'MsgBox(source_index)
        'TextBox1.Text = "Source Index = " & source_index & vbCrLf

        init1()
        dist(source_index) = 0
        For count1 = 0 To 3
            u = path_choice()
            spt_set(u) = 1
            For v = 0 To vertices - 1
                If (spt_set(v) = 0) And (graph(u, v) > 0) And (dist(u) <> inf1) And (dist(u) + graph(u, v) < dist(v)) Then
                    dist(v) = dist(u) + graph(u, v)
                    parent1(v) = u

                End If
            Next
        Next
    End Sub

    Private Function path_choice() As Integer
        Dim min As Integer = inf1
        Dim min_index As Integer = -1
        Dim i As Integer
        For i = 0 To vertices - 1
            If (spt_set(i) = 0) And (dist(i) <= min) Then
                min = dist(i)
                min_index = i
            End If
        Next
        Return min_index

    End Function

    Private Sub init1()
        Dim i As Integer
        For i = 0 To 4
            dist(i) = inf1
            spt_set(i) = 0
            parent1(i) = -1
        Next
    End Sub

    Private Function find_index_mapping(ByVal inputLabel As String) As Integer
        find_index_mapping = -999
        Dim label1 As String
        Dim i As Integer

        For i = 0 To 4
            label1 = labels(i)
            If label1 = inputLabel Then
                Return i
            End If
        Next
    End Function
End Class

