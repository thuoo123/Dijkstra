Imports System.Drawing.Drawing2D

Public Class UserControl2

    Private _radius As Int32 = 20    '5  'Radius     'Radius of the Corner Curve
    Private _opacity As Int32 = 255 '125   'Opacity of the Control
    Private _backColor As System.Drawing.Color '= Color.DarkGreen '.Black 'Back Color of Control
    Private R_Value As Integer
    Private G_Value As Integer
    Private B_Value As Integer

    Public WriteOnly Property R1()
        Set(ByVal value)
            R_Value = value
        End Set
    End Property

    Public WriteOnly Property G1()
        Set(ByVal value)
            G_Value = value
        End Set
    End Property

    Public WriteOnly Property B1()
        Set(ByVal value)
            B_Value = value
        End Set
    End Property

    Private Sub UserControl1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Me.Paint
        Dim rect As Rectangle = Me.ClientRectangle 'Drawing Rounded Rectangle
        rect.X = rect.X + 1
        rect.Y = rect.Y + 1
        rect.Width -= 2
        rect.Height -= 2
        Dim tag1 As Integer = 0

        tag1 = Me.Tag
        Select Case tag1   ' Green1, Orange, Red
            Case 0 : _backColor = ColorTranslator.FromOle(RGB(0, 102, 77)) 'Color.DarkGreen
            Case 1 : _backColor = ColorTranslator.FromOle(RGB(204, 102, 0)) 'Color.Orange
            Case 2 : _backColor = ColorTranslator.FromOle(RGB(255, 0, 0)) 'Color.Red
            Case 3 : _backColor = ColorTranslator.FromOle(RGB(38, 38, 38)) 'Color.Black

                'Case 3 : _backColor = Color.Black   'ColorTranslator.FromOle(RGB(38, 38, 38)) 'Color.Black
        End Select
       
        Using bb As GraphicsPath = GetPath(rect, _radius)
            Using br As Brush = New SolidBrush(Color.FromArgb(_opacity, _backColor))
                e.Graphics.FillPath(br, bb)
            End Using
        End Using
    End Sub

    Protected Function GetPath(ByVal rc As Rectangle, ByVal r As Int32) As GraphicsPath
        Dim x As Int32 = rc.X, y As Int32 = rc.Y, w As Int32 = rc.Width, h As Int32 = rc.Height
        r = r << 1
        Dim path As GraphicsPath = New GraphicsPath()
        If r > 0 Then
            If (r > h) Then r = h
            If (r > w) Then r = w
            path.AddArc(x, y, r, r, 180, 90)
            path.AddArc(x + w - r, y, r, r, 270, 90)
            path.AddArc(x + w - r, y + h - r, r, r, 0, 90)
            path.AddArc(x, y + h - r, r, r, 90, 90)
            path.CloseFigure()
        Else
            path.AddRectangle(rc)
        End If
        Return path
    End Function

    Private Sub UserControl2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        With lblNode
            .BackColor = Color.Transparent
            .ForeColor = Color.White
        End With
    End Sub

End Class
