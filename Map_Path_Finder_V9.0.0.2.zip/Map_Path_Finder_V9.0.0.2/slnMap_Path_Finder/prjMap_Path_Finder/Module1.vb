Module Module1

    Public gstVersion1 As String
    Public gnTotalNode As Integer
    Public gnNodeWidth As Integer
    Public gnNodeHeight As Integer

    Public gstRGB_Value_Orange As String
    Public gstRGB_Value_Red As String
    Public gstRGB_Value_Black As String
    Public gstRGB_Value_Green As String

    Public Structure recColor
        Public R As Integer
        Public G As Integer
        Public B As Integer
    End Structure

    Public Red1 As recColor
    Public Orange1 As recColor
    Public Black1 As recColor
    Public Green1 As recColor

    Public gstNodeID As String
    Public Radius As Integer = 5
End Module
