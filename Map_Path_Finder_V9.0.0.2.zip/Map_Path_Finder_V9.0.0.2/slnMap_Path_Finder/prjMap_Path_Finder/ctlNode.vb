Imports System.IO

Public Class ctlNode
    
    Public Property text1()
        Get
            Return Label1.Text
        End Get
        Set(ByVal value)
            Label1.Text = value
        End Set
    End Property

    Public Sub Relocate1()
        With Label1                ' to show Node Name
            .Left = 1
            .Top = 1
            .AutoSize = False
            .Width = Me.Width - 2
            .Height = Me.Height - 2 '/ 2

            .BackColor = ColorTranslator.FromOle(RGB(Black1.R, Black1.G, Black1.B)) ', 102, 77)) 'Color.Black ' Color.Transparent
            .ForeColor = Color.White
        End With
    End Sub

    Public G() As UserControl2   ' 0 for Green, 1 for Orange, 2 for Red, 3 for Black

    Private Sub UserControl1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim I As Integer
        Dim K As Integer = 0
        K = 3

        ReDim G(K)

        For I = 0 To K
            G(I) = New UserControl2
            G(I).Tag = I                  ' tag is used to draw color (green, orange, red)
            Me.Controls.Add(G(I))
        Next

        Relocate1()
    End Sub
End Class

