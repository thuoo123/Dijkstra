<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UserControl2
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblNode = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblNode
        '
        Me.lblNode.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNode.ForeColor = System.Drawing.Color.Red
        Me.lblNode.Location = New System.Drawing.Point(20, 24)
        Me.lblNode.Name = "lblNode"
        Me.lblNode.Size = New System.Drawing.Size(93, 40)
        Me.lblNode.TabIndex = 0
        Me.lblNode.Text = "Label1"
        Me.lblNode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'UserControl2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Transparent
        Me.Controls.Add(Me.lblNode)
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Name = "UserControl2"
        Me.Size = New System.Drawing.Size(131, 97)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lblNode As System.Windows.Forms.Label

End Class
